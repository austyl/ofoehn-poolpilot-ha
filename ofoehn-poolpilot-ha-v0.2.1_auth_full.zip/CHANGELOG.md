# Changelog

## v0.2.1 — Auth & Examples
- Authentification: NONE/BASIC/QUERY/COOKIE
- Options indices DONNEE#
- Exemples Lovelace ajoutés (full/compact)
- CI: hassfest + HACS action

## v0.2.0
- Première version publique avec auth